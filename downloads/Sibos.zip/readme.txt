S.I.B.O.S
(C) 1998 Andrew Lunn



SYSTEM REQUIREMENTS
-------------------
OS:            MS-DOS 5.0 or Above
Processor:     P100, recommended P166 / P200
Memory:        16 MB (Minimum), 24 (Recommended)
Graphics Card: SVGA - VESA Compatible. 1MB Minimum
Sound Card:    100% Compatible Sound Blaster
Hard Drive:    30 MB of Free Hard Disk Space (If installing)
CD-ROM:        (If running from CD) 8 Speed, 20 Speed (Recommended)

INSTALLING SIBOS
----------------
SIBOS is a DOS application but it will run from Windows 95 in a DOS-BOX.
If you are running it from Windows 95 then go to your CD-Drive and run the
INSTALL.EXE program. If you are running it just from DOS, insert the CD into
your CD drive. Change the directory to that of the CD. For example if your
CD drive is at drive letter D.

CD D: <ENTER>
Then type,
INSTALL <ENTER>

This will launch the SIBOS installer. Simply follow the onscreen instructions.

RUNNING SIBOS FROM CD
---------------------
If you are running it from Windows 95 then go to your CD-Drive and run the
SIBOS.EXE program. If you are running it just from DOS insert the CD into your
CD drive. Change the directory to that of the CD. For example if your CD drive
is at drive letter D.

CD D: <ENTER>
Then type,
SIBOS <ENTER>

WARNING: Running SIBOS from CD can considerably reduce the performance of the
Animation playback and loading times. It is suggested that you install SIBOS if
you have the Harddrive space.

CALIBRATING A JOYSTICK
----------------------
If you have a joystick connected through the MIDI/JOYSTICK port of your sound card
then when SIBOS runs for the first time it will ask you to calibrate it. Follow the
on-screen instructions and these calibration settings will be saved. You will not
have to do this again unless you change your joystick in which case you will need
to re-calibrate. See "COMMAND LINE PARAMTERS section" in 'TECHNICAL.TXT'.

TITLE SCREEN
------------
Once the game has loaded it will go into an intro sequence that will permanently loop
until you either press <ESCAPE>, <ENTER> or a Joystick Button. You are now presented with
the Main Menu options:

NEW GAME
LOAD GAME
OPTIONS

These options can be selected by moving up/down/left/right using the directional keys
or Joystick and activated by pressing the <ENTER> key or Joystick Button.

Pressing the <ESCAPE> key on the Main Menu will quit back to DOS/WINDOWS 95 and when
you are deeper into the menu system <ESCAPE> will go back up a menu level.

NEW GAME    - You will be presented with three menu options each representing a save slot.
              Simply choose one and the game will start at the first level. NOTE: If you
              already have a used save slot, choosing it will wipe it clean.

LOAD GAME   - Choose one of the three game save slots and you will be jumped straight to
              that level with all the previous shield and powerups.

OPTIONS     - This will take you to a sub-menu of three items:
SET VOLUME  - You will be presented with a bar. Use the LEFT/RIGHT cursor keys to decrease
              and increase the volume.
DEFINE KEYS - You will be shown a menu item for each action in the game. Moving over one
              will show the current key assigned to that action. To change it simply press
              <ENTER> (The current assignment will flash) and press the new key you want
              to assign to it.
JOYSTICK    - If a joystick is connected then pressing <ENTER> on this option will toggle
              the use of a joystick in the game. NOTE: When a joystick is used the define
              your own keys menu is disabled.

PLAYING THE GAME
----------------
You take control of the Turret in the centre of the screen. It can be rotated by using the
LEFT/RIGHT action keys or (If you have a mouse installed) by moving the mouse LEFT/RIGHT.
NOTE: the mouse is analogue and is the preferred method of input.

To the left of the screen is a passage where the soldiers advance from. They will keep
advancing at you until the left hand side is full. The soldiers nearest to the turret will
attack by throwing balls at you.

You must point your turret at a soldier and press the activate key. That will suck the
soldier into the turret.

The right side is your Combo area. Once you have a soldier in your turret you must turn to
the right side and fire it out. 

As you will notice there are three different colours of soldier. The idea is to get three
or more soldiers touching on the right hand side. When this happens the touching soldiers
will burst and disappear. To complete a level you must make a designated number of
these combinations.

PANEL
-----
The panel is a raised LCD display at the top of the screen. The top right shows the time
left to finish the level. Below that is your combo quota (Number of combos left to make).
Along the bottom is the turrets shield and finally the left hand side shows the current
powerup held or blank if no powerup available.

POWERUPS
--------
At random intervals during a level metal boxes will appear from the left hand side (instead
of Soldiers) with red "P's" on top of them. These are powerups. To get one, just suck it
up in the same fashion as a Soldier. A random powerup is then chosen. This is shown on the
LCD panel.

There are four powerups in SIBOS and they are as follows:

EXTRA TIME	Press the powerup key to gain extra time
EXTRA SHIELD	Press the powerup key to gain extra shield
BOUNCEY BALL	Press the powerup key for a limited deflector shield
LIGHTNING	Point at an advancing soldier and press the powerup key to destroy
                that soldier.

ADDITIONAL KEYS
---------------
<P>       Pause / Unpause level
<ESCAPE>  Quit the level

BOSS LEVELS
-----------
Every tenth level is a boss level. The boss will arrive from the right side of the screen
and you must destroy it in the time allocated. For these levels your turret will be
equipped with a water cannon. Pressing the activate key will start squirting water. All
the time you are squirting a water level indicator will drop on the panel. If the level
reaches the bottom you can no longer squirt water. To gain the water back simply stop
squirting and the level will rise back up. To hit the boss you must squirt directly at
it (The bosses energy level is on the panel). When the boss attacks your only defence is
to turn away and a force field will protect you.

BONUSES
-------
When you reach the end of a level any remaining time is converted into extra shields for
your turret. So, the quicker you finish a level the more shields you obtain.

BACKGROUND
----------
SIBOS is the greatest game show ever. A colossus, constructed, metallic planet roams the
galaxies plucking unsuspecting victims to play for their life. The show is broadcast live
to every Planet in the solar system and everyone loves it.

Unfortunately the next planet of choice was Earth and the victim was YOU!!!!
