P  Y  R  O  M  A  N  I  A
-------------------------
By Andrew Lunn 1997


============
= Contents =
============

Pyromania System Requirements....
Playing Pyromania................
Keyboard Operations..............
Pyromania Menus..................
Command Line.....................
Credits..........................

=================================
= Pyromania System Requirements	=
=================================

IBM PC and Compatibles
Pentium processor HIGHLY recommended, 486DX2/50 Minimally required
VGA Compatible Display
Sound Blaster or Compatible
4MB RAM required
MS-DOS (Will run in a Dos Prompt under Windows 95)
Hard Drive (2MB)

=====================
= Playing Pyromania =
=====================

Game Rules
----------

Destroy the blocks that fall into your playing field. You can obstruct
your opponent's game play by dropping blocks into his or her playing field.

Know your Blocks
----------------

There are four types of blocks in Pyromania. Rocket, Catherine Wheel, Volcano
and Sparkler. Each time you manage to touch four or more of the same blocks
in your playing field a firework of that type will be triggered and these
blocks will disappear. Now any blocks above will be dropped, this could in
turn cause another reaction. The number of these "Chain Reactions" determines
the amount of bad blocks to be dropped on the opponents side. The blocks
dropped on the opponents side are of a different type (Grey Exclamation). The
only way to remove these are to cause a firework around them. You'll know when
bad blocks are coming because your sides large green rocket will flash and a
scream will be heard.

Assess your progress
--------------------

Throughout a match if you wish to know who's winning quickly, simply look at
Pooyan Pigs face in the centre of the screen. Who ever he's looking at is
winning.

=======================
= Keyboard Operations =
=======================

Basic Operation
---------------

DOWN
Increases the falling speed of the blocks. 

RIGHT-LEFT 
Moves the blocks RIGHT or LEFT on the playing field.

ROTATE
Rotates blocks on the playing field.

Using the Keyboard
------------------

Below are the default keyboard layouts for controls:-

Player 1:

DOWN	         Down Arrow
LEFT	         Left Arrow
RIGHT	         Right Arrow
ROTATE
(Anti Clockwise) Either Control Key
ROTATE
(Clockwise)      Either Alt Key

Player 2:

DOWN             E
LEFT	         W
RIGHT	         R
ROTATE
(Anti Clockwise) TAB
ROTATE
(Clockwise)      Q

Additional Keys
---------------

PAUSE            P
QUIT TO TITLE    Esc

===================
= Pyromania Menus =
===================

From the title screen pressing any key will bring up the main menu:

Main Menu
---------

1 PLAYER MATCH - Play against the Computer through 8 stages of increasingly
more difficult skill levels.

2 PLAYER MATCH - Take on a challenge against a friend. The same rules apply
as to a sinle player game except the game is now human controlled.

OPTIONS - See below for options available.

EXIT - Quit out back to DOS. At this point your game configuration will be
saved out.

Options Menu
------------

2 PLAYER MATCHES - The number of matches you would like to play in a 2 playe
match. Using left/right arrow keys increases and lowers number of matches.

SOUND VOLUME - Set the sound effects volume from 0 (Silent) - 8 (Maximum).

SWAP KEYS IN 2UP GAME - When in a two player mode the persons playing will be
arranged in such a manor on the keyboard that they will be looking at the
opposite side of the screen. So I have added this option to swap the
keys around.

AUTO DROP ON/OFF - This switches the action of the Drop key. ON means pressing
the down key during play will drop the pieces all the way. OFF means you have
to hold the down key to drop the pieces. Letting go stops the drop.

BACK - Go back to the Main Menu. Nothing more, nothing less.

================
= Command Line =
================

Pyromania has the following command line parameters:

-nosound This will cancel any sound initialisation or playback. Use
this if you have trouble starting Pyromania with your sound card or do not
wish to use sound at all.

-blaster #io #irq #dma <#dma16> Pyromania will normally self detect your
sound blaster settings but if for some reason it fails then you can use
this command to force your card settings. Consult your manuals for how to
obtain these figures. Note: dma16 is optional depending on the card you have.

-verbose Using this will print out initialization information as Pyromania
boots up. It was intentionally for my purposes but I just left it in.

===========
= Credits =
===========

Design, Code, Art, Sfx ... Andrew Lunn

Sound Driver ............. Ethan Brodsky

Testing .................. Stuart Indoe
                           Jim Cadwallader
                           Richard Lawrence
                           Tim Lewis
                           Steven Lunn
